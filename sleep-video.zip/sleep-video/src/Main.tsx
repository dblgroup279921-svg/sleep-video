import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { theme } from "./theme";
import { T, transitionFrames } from "./timing";
import { BgMesh, Grade, Grain, Vignette } from "./components/Layers";
import { PreviewAudio } from "./components/PreviewAudio";
import { Sfx } from "./components/Sfx";
import { Hook } from "./scenes/Hook";
import { Brain } from "./scenes/Brain";
import { Mood } from "./scenes/Mood";
import { Risk } from "./scenes/Risk";
import { Habit } from "./scenes/Habit";

const SCENES: { timing: { from: number; duration: number }; Scene: React.FC }[] = [
  { timing: T.hook, Scene: Hook },
  { timing: T.brain, Scene: Brain },
  { timing: T.mood, Scene: Mood },
  { timing: T.risk, Scene: Risk },
  { timing: T.habit, Scene: Habit },
];

export const Main: React.FC = () => (
  <AbsoluteFill style={{ backgroundColor: theme.colors.bg, fontFamily: theme.fonts.body }}>
    {/* স্তর ১: ব্যাকগ্রাউন্ড মেশ */}
    <BgMesh />

    {/* স্তর ২–৩: সিনের অ্যাসেট ও গ্রাফিক্স */}
    {SCENES.map(({ timing, Scene }, i) => (
      <Sequence key={i} from={timing.from} durationInFrames={timing.duration}>
        <Scene />
      </Sequence>
    ))}

    {/* সিন ট্রানজিশন: ছোট ও মসৃণ whoosh */}
    {transitionFrames.map((f, i) => (
      <Sfx key={i} name="whoosh" at={f} volume={0.28} rate={i % 2 ? 1.06 : 0.97} />
    ))}

    {/* স্তর ৪–৫: গ্রেড, গ্রেইন, ভিনিয়েট */}
    <Grade />
    <Grain />
    <Vignette />

    {/* প্রিভিউ-ভয়েসওভার (public/voiceover.mp3 থাকলে) */}
    <PreviewAudio />
  </AbsoluteFill>
);
