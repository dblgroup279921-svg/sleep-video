// প্রিভিউ/রেন্ডার সুইচ।
export const config = {
  voiceover: {
    // true হলে Studio প্রিভিউতে public/voiceover.mp3 বাজবে (ফাইল না থাকলে নীরবে বাদ)
    enabled: true,
    // ডিফল্টে রেন্ডারে বন্ধ। ভয়েসওভারসহ MP4 চাইলে true করুন।
    inRender: false,
    file: "voiceover.mp3",
  },
} as const;
