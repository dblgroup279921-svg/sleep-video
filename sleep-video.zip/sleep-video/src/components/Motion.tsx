import React from "react";
import {
  AbsoluteFill,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { theme } from "../theme";

export const clamp01 = {
  extrapolateLeft: "clamp",
  extrapolateRight: "clamp",
} as const;

type SpringName = keyof typeof theme.spring;

// স্প্রিং প্রগ্রেস (০→১, সামান্য ওভারশুট সম্ভব)
export const useSpring = (delay = 0, preset: SpringName = "smooth") => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: frame - delay, fps, config: theme.spring[preset] });
};

// প্রিমিয়াম এন্ট্রান্স: opacity + translateY + scale একসাথে
export const Entrance: React.FC<{
  delay?: number;
  y?: number;
  from?: number;
  preset?: SpringName;
  style?: React.CSSProperties;
  children: React.ReactNode;
}> = ({ delay = 0, y = 44, from = 0.94, preset = "smooth", style, children }) => {
  const p = useSpring(delay, preset);
  return (
    <div
      style={{
        opacity: Math.min(1, Math.max(0, p * 1.4)),
        transform: `translateY(${interpolate(p, [0, 1], [y, 0])}px) scale(${interpolate(
          p,
          [0, 1],
          [from, 1],
        )})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

// ওয়ার্ড-বাই-ওয়ার্ড স্ট্যাগার্ড। বিভাজন শুধু স্পেসে, অক্ষর ভাঙা নয়।
export const Words: React.FC<{
  text: string;
  size: number;
  delay?: number;
  per?: number;
  weight?: number;
  color?: string;
  highlight?: number[]; // হাইলাইট হবে এমন শব্দের সূচক
  highlightColor?: string;
  align?: "flex-start" | "center" | "flex-end";
  style?: React.CSSProperties;
}> = ({
  text,
  size,
  delay = 0,
  per = 4,
  weight = theme.weights.display,
  color = theme.colors.text,
  highlight = [],
  highlightColor = theme.colors.accent,
  align = "flex-start",
  style,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: align,
        columnGap: Math.round(size * 0.26),
        fontFamily: theme.fonts.display,
        fontSize: size,
        fontWeight: weight,
        lineHeight: 1.4,
        letterSpacing: 0,
        color,
        ...style,
      }}
    >
      {text.split(" ").map((word, i) => {
        const p = spring({
          frame: frame - delay - i * per,
          fps,
          config: theme.spring.snappy,
        });
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              opacity: Math.min(1, Math.max(0, p * 1.5)),
              transform: `translateY(${interpolate(p, [0, 1], [34, 0])}px) scale(${interpolate(
                p,
                [0, 1],
                [0.92, 1],
              )})`,
              color: highlight.includes(i) ? highlightColor : color,
              textShadow: highlight.includes(i)
                ? `0 0 40px ${theme.colors.accentGlow}`
                : undefined,
            }}
          >
            {word}
          </span>
        );
      })}
    </div>
  );
};

// সিনের মোড়ক: শেষ ১০ ফ্রেমে দ্রুত এক্সিট (এন্ট্রির চেয়ে দ্রুত)
export const SceneShell: React.FC<{ exit?: boolean; children: React.ReactNode }> = ({
  exit = true,
  children,
}) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const t = exit
    ? interpolate(frame, [durationInFrames - 10, durationInFrames - 1], [0, 1], {
        easing: theme.ease.in,
        ...clamp01,
      })
    : 0;
  return (
    <AbsoluteFill
      style={{
        opacity: 1 - t,
        transform: `translateY(${-28 * t}px) scale(${1 + 0.03 * t})`,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};

// ভাসমান/শ্বাস নেওয়া মাইক্রো-মোশন
export const useBreathe = (period = 22, amp = 0.015) => {
  const frame = useCurrentFrame();
  return 1 + Math.sin(frame / period) * amp;
};

export const toBengaliDigits = (n: number | string): string =>
  String(n).replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[Number(d)]);
