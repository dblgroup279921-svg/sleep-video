import React, { useEffect, useState } from "react";
import { Audio, getRemotionEnvironment, staticFile } from "remotion";
import { config } from "../config";

// public/voiceover.mp3 থাকলে বাজে, না থাকলে নীরবে বাদ।
// ডিফল্টে শুধু Studio প্রিভিউতে বাজে; রেন্ডারে বন্ধ (config.voiceover.inRender)।
export const PreviewAudio: React.FC = () => {
  const rendering = getRemotionEnvironment().isRendering;
  const allowed = config.voiceover.enabled && (!rendering || config.voiceover.inRender);
  const [exists, setExists] = useState(false);

  useEffect(() => {
    if (!allowed) return;
    let cancelled = false;
    fetch(staticFile(config.voiceover.file), { method: "HEAD" })
      .then((res) => {
        const type = res.headers.get("content-type") ?? "";
        if (!cancelled && res.ok && !type.includes("text/html")) setExists(true);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [allowed]);

  if (!allowed || !exists) return null;
  return <Audio src={staticFile(config.voiceover.file)} />;
};
