import React from "react";
import { theme } from "../theme";

// গ্লাস কার্ড: পুরো ভিডিওতে একই গোলাকার ভাব, ছায়া ও বর্ডার
export const Card: React.FC<{
  width: number;
  height: number;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({ width, height, style, children }) => (
  <div
    style={{
      width,
      height,
      borderRadius: theme.radius.card,
      background: `linear-gradient(160deg, ${theme.colors.surfaceStrong}, ${theme.colors.surface})`,
      border: `1.5px solid ${theme.colors.border}`,
      boxShadow: theme.shadow.card,
      backdropFilter: "blur(18px)",
      position: "relative",
      ...style,
    }}
  >
    {children}
  </div>
);
