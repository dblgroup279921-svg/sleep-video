// যুক্তাক্ষর ঠিকমতো আসে এমন বাংলা ফন্ট: Hind Siliguri।
// loadFont নিজেই delayRender সামলায়, তাই ফন্ট লোড না হওয়া পর্যন্ত ফ্রেম রেন্ডার হয় না।
import { loadFont } from "@remotion/google-fonts/HindSiliguri";

export const hindSiliguri = loadFont("normal", {
  weights: ["500", "600", "700"],
  subsets: ["bengali", "latin"],
});
