// theme.ts — একমাত্র সত্য-উৎস: রং, ইজিং, spring, ফন্ট, মাপ।
// কম্পোনেন্টে সরাসরি রঙের কোড বা ইজিং লেখা নিষেধ।
import { Easing } from "remotion";

export const video = {
  width: 1920,
  height: 1080,
  fps: 30,
} as const;

// রং স্কিম: "মধ্যরাতের নীল"
export const theme = {
  colors: {
    bg: "#0B1026",
    bgAlt: "#131B42",
    primary: "#6C7BFF", // হিরো
    accent: "#FFC857",
    text: "#F2F4FF",
    textDim: "#A9B2DE",
    // ওপরের রং থেকে তৈরি স্বচ্ছ/নরম রূপ
    surface: "rgba(255,255,255,0.06)",
    surfaceStrong: "rgba(255,255,255,0.10)",
    border: "rgba(255,255,255,0.16)",
    track: "rgba(255,255,255,0.12)",
    glow: "rgba(108,123,255,0.45)",
    primarySoft: "rgba(108,123,255,0.28)",
    accentGlow: "rgba(255,200,87,0.40)",
    accentSoft: "rgba(255,200,87,0.22)",
    shadow: "rgba(3,5,20,0.60)",
  },
  fonts: {
    // fonts.ts এই ফন্ট লোড করে
    display: "'Hind Siliguri', 'Noto Sans Bengali', sans-serif",
    body: "'Hind Siliguri', 'Noto Sans Bengali', sans-serif",
  },
  weights: { display: 700, strong: 600, body: 500 },
  radius: { card: 36, pill: 999, small: 20 },
  shadow: {
    card: "0 40px 80px -28px rgba(3,5,20,0.75), inset 0 1px 0 rgba(255,255,255,0.10)",
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
} as const;
