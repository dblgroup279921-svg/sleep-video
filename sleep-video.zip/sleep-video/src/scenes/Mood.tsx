import React from "react";
import { AbsoluteFill, interpolate, interpolateColors, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Card } from "../components/Card";
import { Entrance, SceneShell, Words, clamp01 } from "../components/Motion";
import { Sfx } from "../components/Sfx";
import { T } from "../timing";

// সিন ৩ (cue ২): Before/After ধাঁচের দুই প্যানেল — মেজাজ ও ক্লান্তি
const PANEL = { w: 800, h: 700, y: 190, xs: [110, 1010] };

const Face: React.FC<{ at: number }> = ({ at }) => {
  const frame = useCurrentFrame();
  const t = interpolate(frame, [at + 16, at + 60], [0, 1], {
    easing: theme.ease.inOut,
    ...clamp01,
  });
  const stroke = interpolateColors(t, [0, 1], [theme.colors.text, theme.colors.accent]);
  const mouthY = 48 + 30 * t;
  const ctrlY = 108 - 88 * t;
  const pulse = interpolate(frame, [at + 60, at + 66, at + 92, at + 98], [0, 1, 1, 0], clamp01);
  const shake = Math.sin(frame * 2.3) * 3.5 * pulse;
  return (
    <svg width={400} height={400} viewBox="-150 -150 300 300">
      <g transform={`translate(${shake} 0)`}>
        <circle
          cx={0}
          cy={0}
          r={122}
          fill={theme.colors.surface}
          stroke={stroke}
          strokeWidth={8}
        />
        <circle cx={-42} cy={-12} r={11} fill={stroke} />
        <circle cx={42} cy={-12} r={11} fill={stroke} />
        <g transform={`rotate(${22 * t} -46 -50)`}>
          <line x1={-76} y1={-50} x2={-16} y2={-50} stroke={stroke} strokeWidth={9} strokeLinecap="round" />
        </g>
        <g transform={`rotate(${-22 * t} 46 -50)`}>
          <line x1={16} y1={-50} x2={76} y2={-50} stroke={stroke} strokeWidth={9} strokeLinecap="round" />
        </g>
        <path
          d={`M-56 ${mouthY} Q0 ${ctrlY} 56 ${mouthY}`}
          fill="none"
          stroke={stroke}
          strokeWidth={9}
          strokeLinecap="round"
        />
      </g>
    </svg>
  );
};

const Battery: React.FC<{ at: number }> = ({ at }) => {
  const frame = useCurrentFrame();
  const level = interpolate(frame, [at + 8, at + 44], [1, 0.12], {
    easing: theme.ease.inOut,
    ...clamp01,
  });
  const fill = interpolateColors(level, [0.12, 0.5], [theme.colors.accent, theme.colors.primary]);
  const blink = level < 0.2 ? 0.65 + 0.35 * Math.sin(frame / 4) : 1;
  return (
    <svg width={440} height={240} viewBox="0 0 440 240">
      <rect
        x={12}
        y={32}
        width={360}
        height={176}
        rx={40}
        fill={theme.colors.surface}
        stroke={theme.colors.text}
        strokeWidth={10}
      />
      <rect x={384} y={88} width={30} height={64} rx={10} fill={theme.colors.text} />
      <rect
        x={32}
        y={52}
        width={320 * level}
        height={136}
        rx={24}
        fill={fill}
        opacity={blink}
      />
    </svg>
  );
};

const Panel: React.FC<{
  x: number;
  at: number;
  label: string;
  highlight: number[];
  children: React.ReactNode;
}> = ({ x, at, label, highlight, children }) => (
  <Entrance delay={at} y={50} style={{ position: "absolute", left: x, top: PANEL.y }}>
    <Card width={PANEL.w} height={PANEL.h}>
      <div
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          top: 60,
          height: 400,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {children}
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 56, display: "flex", justifyContent: "center" }}>
        <Words text={label} size={78} delay={at + 12} per={5} align="center" highlight={highlight} />
      </div>
    </Card>
  </Entrance>
);

export const Mood: React.FC = () => {
  const [a, b] = T.mood.items;
  return (
    <SceneShell>
      <AbsoluteFill>
        <Panel x={PANEL.xs[0]} at={a} label="মেজাজ খিটখিটে" highlight={[1]}>
          <Face at={a} />
        </Panel>
        <Panel x={PANEL.xs[1]} at={b} label="সারাদিন ক্লান্ত" highlight={[1]}>
          <Battery at={b} />
        </Panel>
      </AbsoluteFill>

      <Sfx name="pop" at={a - 2} volume={0.28} rate={1.03} />
      <Sfx name="pop" at={b - 2} volume={0.26} rate={0.94} />
    </SceneShell>
  );
};
