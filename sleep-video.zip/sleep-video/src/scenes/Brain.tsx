import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Card } from "../components/Card";
import { BrainIcon, ArrowDown } from "../components/Icons";
import { Entrance, SceneShell, Words, clamp01, useSpring } from "../components/Motion";
import { Sfx } from "../components/Sfx";
import { T } from "../timing";

// সিন ২ (cue ১): Hub and Spoke — মস্তিষ্ক কেন্দ্রে, তিনটি ক্ষমতা কমছে
const HUB = { x: 480, y: 520, r: 210 };
const CARD = { x: 900, w: 860, h: 200, ys: [260, 520, 780] };
const LABELS = ["মনোযোগ", "স্মৃতিশক্তি", "সিদ্ধান্ত নেওয়ার ক্ষমতা"];
const RATES = [1, 1.06, 0.95];

const Spoke: React.FC<{ y: number; at: number }> = ({ y, at }) => {
  const frame = useCurrentFrame();
  const p = interpolate(frame, [at - 10, at + 8], [0, 1], {
    easing: theme.ease.out,
    ...clamp01,
  });
  const x0 = HUB.x + HUB.r;
  const d = `M${x0} ${HUB.y} C${x0 + 90} ${HUB.y}, ${CARD.x - 110} ${y}, ${CARD.x} ${y}`;
  return (
    <svg
      width={1920}
      height={1080}
      style={{ position: "absolute", left: 0, top: 0, pointerEvents: "none" }}
    >
      <path
        d={d}
        fill="none"
        stroke={theme.colors.border}
        strokeWidth={4}
        strokeLinecap="round"
        pathLength={1}
        strokeDasharray={1}
        strokeDashoffset={1 - p}
      />
      <circle cx={CARD.x} cy={y} r={9 * p} fill={theme.colors.accent} />
    </svg>
  );
};

const SkillCard: React.FC<{ label: string; y: number; at: number }> = ({ label, y, at }) => {
  const frame = useCurrentFrame();
  // মিটার ভরা থেকে নেমে যায়
  const level = interpolate(frame, [at + 14, at + 62], [1, 0.24], {
    easing: theme.ease.inOut,
    ...clamp01,
  });
  const arrow = useSpring(at + 40, "bouncy");
  return (
    <Entrance
      delay={at}
      y={36}
      style={{ position: "absolute", left: CARD.x, top: y - CARD.h / 2 }}
    >
      <Card width={CARD.w} height={CARD.h}>
        <div
          style={{
            position: "absolute",
            left: 44,
            top: 22,
            fontFamily: theme.fonts.display,
            fontWeight: theme.weights.display,
            fontSize: 58,
            lineHeight: 1.4,
            color: theme.colors.text,
            letterSpacing: 0,
          }}
        >
          {label}
        </div>
        <div
          style={{
            position: "absolute",
            right: 40,
            top: 40,
            opacity: Math.min(1, Math.max(0, arrow)),
            transform: `translateY(${interpolate(arrow, [0, 1], [-16, 0])}px)`,
          }}
        >
          <ArrowDown size={58} />
        </div>
        <div
          style={{
            position: "absolute",
            left: 44,
            right: 44,
            bottom: 36,
            height: 20,
            borderRadius: theme.radius.pill,
            background: theme.colors.track,
            overflow: "hidden",
          }}
        >
          <div
            style={{
              width: `${level * 100}%`,
              height: "100%",
              borderRadius: theme.radius.pill,
              background: theme.colors.accent,
            }}
          />
        </div>
      </Card>
    </Entrance>
  );
};

export const Brain: React.FC = () => {
  const frame = useCurrentFrame();
  const hub = useSpring(2, "smooth");
  const draw = interpolate(frame, [4, 40], [0, 1], { easing: theme.ease.out, ...clamp01 });
  const pulse = (frame % 60) / 60;
  const breathe = 1 + Math.sin(frame / 22) * 0.015;
  const items = T.brain.items;

  return (
    <SceneShell>
      <AbsoluteFill>
        {items.map((at, i) => (
          <Spoke key={i} y={CARD.ys[i]} at={at} />
        ))}

        {/* হাব */}
        <div
          style={{
            position: "absolute",
            left: HUB.x - HUB.r,
            top: HUB.y - HUB.r,
            width: HUB.r * 2,
            height: HUB.r * 2,
            opacity: Math.min(1, hub * 1.4),
            transform: `scale(${interpolate(hub, [0, 1], [0.8, 1]) * breathe})`,
          }}
        >
          <div
            style={{
              position: "absolute",
              inset: 0,
              borderRadius: "50%",
              background: `radial-gradient(circle, ${theme.colors.primarySoft}, ${theme.colors.surface} 70%)`,
              border: `3px solid ${theme.colors.primary}`,
              boxShadow: `0 0 90px ${theme.colors.glow}`,
            }}
          />
          <div
            style={{
              position: "absolute",
              inset: 0,
              borderRadius: "50%",
              border: `2px solid ${theme.colors.primary}`,
              opacity: (1 - pulse) * 0.6,
              transform: `scale(${1 + pulse * 0.35})`,
            }}
          />
          <div
            style={{
              position: "absolute",
              left: 0,
              right: 0,
              top: "50%",
              display: "flex",
              justifyContent: "center",
              transform: "translateY(-50%)",
            }}
          >
            <BrainIcon size={290} p={draw} />
          </div>
        </div>

        <div
          style={{
            position: "absolute",
            left: HUB.x - 260,
            width: 520,
            top: HUB.y + HUB.r + 24,
            display: "flex",
            justifyContent: "center",
          }}
        >
          <Words text="মস্তিষ্ক" size={68} delay={10} align="center" />
        </div>

        {LABELS.map((label, i) => (
          <SkillCard key={label} label={label} y={CARD.ys[i]} at={items[i]} />
        ))}
      </AbsoluteFill>

      {/* হাব ও তিন কার্ড রিভিল: soft pop (পিচ সামান্য বদলে) */}
      <Sfx name="pop" at={3} volume={0.28} />
      {items.map((at, i) => (
        <Sfx key={i} name="pop" at={at - 2} volume={0.26} rate={RATES[i]} />
      ))}
    </SceneShell>
  );
};
