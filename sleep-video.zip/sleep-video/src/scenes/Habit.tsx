import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { CheckIcon } from "../components/Icons";
import {
  Entrance,
  SceneShell,
  Words,
  clamp01,
  toBengaliDigits,
  useSpring,
} from "../components/Motion";
import { Sfx } from "../components/Sfx";
import { T } from "../timing";

// সিন ৫ (cue ৪): প্রথম বাক্য → Clock (নির্দিষ্ট সময়), দ্বিতীয় বাক্য → Counter (অন্তত ৭ ঘণ্টা)
const CLOCK = { cx: 560, cy: 540, r: 250 };
const LOCK_ANGLE = 300; // মার্কারের কোণ (১০টার দিক), শুধু ভিজ্যুয়াল — কোনো নির্দিষ্ট সময় বলা হচ্ছে না
const COUNT_FRAMES = 26;

const Clock: React.FC<{ delay: number }> = ({ delay }) => {
  const frame = useCurrentFrame();
  const enter = useSpring(delay, "smooth");
  const sweepEnd = delay + 54;
  const angle = interpolate(frame, [delay + 14, sweepEnd], [90, LOCK_ANGLE], {
    easing: theme.ease.out,
    ...clamp01,
  });
  const locked = interpolate(frame, [sweepEnd - 4, sweepEnd + 10], [0, 1], clamp01);
  const check = useSpring(sweepEnd + 4, "bouncy");
  const rad = ((LOCK_ANGLE - 90) * Math.PI) / 180;
  const mx = CLOCK.r + Math.cos(rad) * (CLOCK.r - 52);
  const my = CLOCK.r + Math.sin(rad) * (CLOCK.r - 52);
  const pulse = 1 + 0.12 * Math.sin(frame / 6) * locked;

  return (
    <div
      style={{
        position: "absolute",
        left: CLOCK.cx - CLOCK.r,
        top: CLOCK.cy - CLOCK.r,
        width: CLOCK.r * 2,
        height: CLOCK.r * 2,
        opacity: Math.min(1, enter * 1.4),
        transform: `scale(${interpolate(enter, [0, 1], [0.86, 1])})`,
      }}
    >
      <svg width={CLOCK.r * 2} height={CLOCK.r * 2} viewBox={`0 0 ${CLOCK.r * 2} ${CLOCK.r * 2}`}>
        <circle
          cx={CLOCK.r}
          cy={CLOCK.r}
          r={CLOCK.r - 6}
          fill={theme.colors.surface}
          stroke={theme.colors.border}
          strokeWidth={4}
        />
        {Array.from({ length: 12 }).map((_, i) => {
          const a = (i * 30 - 90) * (Math.PI / 180);
          const r1 = CLOCK.r - 40;
          const r2 = CLOCK.r - (i % 3 === 0 ? 70 : 56);
          return (
            <line
              key={i}
              x1={CLOCK.r + Math.cos(a) * r1}
              y1={CLOCK.r + Math.sin(a) * r1}
              x2={CLOCK.r + Math.cos(a) * r2}
              y2={CLOCK.r + Math.sin(a) * r2}
              stroke={theme.colors.textDim}
              strokeWidth={i % 3 === 0 ? 8 : 5}
              strokeLinecap="round"
            />
          );
        })}
        {/* মার্কার: চাঁদের ক্রিসেন্ট */}
        <g transform={`translate(${mx} ${my}) scale(${pulse})`}>
          <circle r={34} fill={theme.colors.accentSoft} opacity={locked} />
          <mask id="clock-crescent">
            <rect x={-30} y={-30} width={60} height={60} fill="white" />
            <circle cx={11} cy={-6} r={20} fill="black" />
          </mask>
          <circle r={24} fill={theme.colors.accent} mask="url(#clock-crescent)" />
        </g>
        {/* কাঁটা */}
        <g style={{ transformOrigin: `${CLOCK.r}px ${CLOCK.r}px`, transform: `rotate(${angle}deg)` }}>
          <line
            x1={CLOCK.r}
            y1={CLOCK.r}
            x2={CLOCK.r}
            y2={CLOCK.r - (CLOCK.r - 96)}
            stroke={theme.colors.text}
            strokeWidth={11}
            strokeLinecap="round"
          />
        </g>
        <circle cx={CLOCK.r} cy={CLOCK.r} r={16} fill={theme.colors.primary} />
      </svg>
      <div
        style={{
          position: "absolute",
          left: CLOCK.r - 36,
          top: CLOCK.r + 70,
          opacity: Math.min(1, Math.max(0, check)),
          transform: `scale(${interpolate(check, [0, 1], [0.5, 1])})`,
        }}
      >
        <CheckIcon size={72} p={Math.min(1, Math.max(0, check))} />
      </div>
    </div>
  );
};

const PartA: React.FC = () => {
  const frame = useCurrentFrame();
  const { split } = T.habit;
  const out = interpolate(frame, [split - 2, split + 8], [0, 1], {
    easing: theme.ease.in,
    ...clamp01,
  });
  return (
    <AbsoluteFill
      style={{
        opacity: 1 - out,
        transform: `translateY(${-30 * out}px) scale(${1 + 0.03 * out})`,
      }}
    >
      <Clock delay={2} />
      <div style={{ position: "absolute", left: 960, top: 300 }}>
        <Words text="প্রতিদিন" size={78} delay={4} color={theme.colors.textDim} weight={theme.weights.strong} />
        <Words text="নির্দিষ্ট সময়ে" size={128} delay={12} per={5} highlight={[0]} />
        <Words text="ঘুমানোর চেষ্টা" size={88} delay={24} per={5} weight={theme.weights.strong} />
      </div>
    </AbsoluteFill>
  );
};

const PartB: React.FC = () => {
  const frame = useCurrentFrame();
  const { split, seven } = T.habit;
  const countEnd = seven + COUNT_FRAMES;
  const value = interpolate(frame, [seven, countEnd], [0, 7], {
    easing: theme.ease.out,
    ...clamp01,
  });
  const shown = Math.round(value);
  const pop = useSpring(countEnd, "bouncy");
  const numScale = frame >= countEnd ? 1 + 0.08 * Math.max(0, 1 - pop) : 1;

  return (
    <AbsoluteFill>
      <div
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          top: 150,
          display: "flex",
          justifyContent: "center",
        }}
      >
        <Words text="প্রাপ্তবয়স্কদের সাধারণত" size={66} delay={split} color={theme.colors.textDim} weight={theme.weights.strong} align="center" />
      </div>

      <Entrance
        delay={split + 8}
        y={40}
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          top: 250,
          display: "flex",
          justifyContent: "center",
          alignItems: "baseline",
          columnGap: 40,
          fontFamily: theme.fonts.display,
          fontWeight: theme.weights.display,
          letterSpacing: 0,
        }}
      >
        <span style={{ fontSize: 100, lineHeight: 1.4, color: theme.colors.text }}>অন্তত</span>
        <span
          style={{
            fontSize: 330,
            lineHeight: 1.15,
            minWidth: 230,
            textAlign: "center",
            color: theme.colors.primary,
            textShadow: `0 0 80px ${theme.colors.glow}`,
            fontVariantNumeric: "tabular-nums",
            transform: `scale(${numScale})`,
            display: "inline-block",
          }}
        >
          {toBengaliDigits(shown)}
        </span>
        <span style={{ fontSize: 130, lineHeight: 1.4, color: theme.colors.text }}>ঘণ্টা</span>
      </Entrance>

      {/* ৭টি পিল: গোনার সাথে একে একে ভরে */}
      <div
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          top: 690,
          display: "flex",
          justifyContent: "center",
          columnGap: 18,
        }}
      >
        {Array.from({ length: 7 }).map((_, i) => {
          const filled = interpolate(value, [i, i + 0.6], [0, 1], clamp01);
          return (
            <Entrance key={i} delay={split + 14 + i * 3} y={20} from={0.9}>
              <div
                style={{
                  width: 112,
                  height: 36,
                  borderRadius: theme.radius.pill,
                  background: theme.colors.track,
                  overflow: "hidden",
                }}
              >
                <div
                  style={{
                    width: `${filled * 100}%`,
                    height: "100%",
                    borderRadius: theme.radius.pill,
                    background: theme.colors.accent,
                  }}
                />
              </div>
            </Entrance>
          );
        })}
      </div>

      <div
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          top: 780,
          display: "flex",
          justifyContent: "center",
        }}
      >
        <Words text="ঘুম প্রয়োজন" size={88} delay={countEnd - 6} per={5} align="center" />
      </div>
    </AbsoluteFill>
  );
};

export const Habit: React.FC = () => {
  const { split, seven } = T.habit;
  return (
    <SceneShell exit={false}>
      <PartA />
      <PartB />

      <Sfx name="pop" at={4} volume={0.28} />
      <Sfx name="click" at={2 + 54 - 2} volume={0.32} />
      <Sfx name="whoosh" at={split - 3} volume={0.24} rate={1.08} />
      <Sfx name="chime" at={seven + COUNT_FRAMES - 3} volume={0.26} />
    </SceneShell>
  );
};
