// ভয়েসওভার SRT — ভিডিওর সব সময়ের একমাত্র উৎস।
export const SRT = `1
00:00:05,000 --> 00:00:11,000
পর্যাপ্ত ঘুম না হলে আপনার মস্তিষ্কের মনোযোগ, স্মৃতিশক্তি এবং সিদ্ধান্ত নেওয়ার ক্ষমতা কমে যেতে পারে।

2
00:00:11,000 --> 00:00:17,000
এমনকি মেজাজ খিটখিটে হতে পারে এবং সারাদিন ক্লান্ত লাগতে পারে।

3
00:00:17,000 --> 00:00:24,000
দীর্ঘদিন ঘুমের ঘাটতি থাকলে হৃদরোগ, উচ্চ রক্তচাপ ও ডায়াবেটিসের ঝুঁকিও বাড়তে পারে।

4
00:00:24,000 --> 00:00:32,000
তাই প্রতিদিন নির্দিষ্ট সময়ে ঘুমানোর চেষ্টা করুন। প্রাপ্তবয়স্কদের সাধারণত অন্তত ৭ ঘণ্টা ঘুম প্রয়োজন।
`;

export type Cue = { index: number; start: number; end: number; text: string };

const TIME = /(\d+):(\d+):(\d+)[,.](\d+)/;
const toSec = (s: string): number => {
  const m = s.match(TIME);
  if (!m) throw new Error(`SRT সময় পড়া যায়নি: ${s}`);
  return Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]) + Number(m[4]) / 1000;
};

export function parseSrt(src: string): Cue[] {
  return src
    .trim()
    .split(/\r?\n\s*\r?\n/)
    .map((block) => {
      const lines = block.trim().split(/\r?\n/);
      const [a, b] = lines[1].split("-->");
      return {
        index: Number(lines[0]),
        start: toSec(a),
        end: toSec(b),
        text: lines.slice(2).join(" ").trim(),
      };
    });
}
