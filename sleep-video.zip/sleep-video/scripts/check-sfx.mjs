// SFX যাচাই: দৈর্ঘ্য, peak, RMS, clipping, শেষের নিঃশব্দতা।
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const dir = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "public", "sfx");
const LIMIT = { pop: 0.5, click: 0.5, chime: 0.5, thud: 0.5, whoosh: 0.8 };
const db = (v) => (v > 0 ? (20 * Math.log10(v)).toFixed(1) : "-inf");
let bad = 0;

console.log("name     dur(s)  peak(dBFS)  rms(dBFS)  clip  tail-end");
for (const file of fs.readdirSync(dir).filter((f) => f.endsWith(".wav")).sort()) {
  const name = file.replace(".wav", "");
  const buf = fs.readFileSync(path.join(dir, file));
  const sr = buf.readUInt32LE(24);
  const n = (buf.length - 44) / 2;
  let peak = 0;
  let sum = 0;
  let clip = 0;
  for (let i = 0; i < n; i++) {
    const v = buf.readInt16LE(44 + i * 2) / 32768;
    peak = Math.max(peak, Math.abs(v));
    sum += v * v;
    if (Math.abs(v) >= 0.999) clip++;
  }
  const last = Math.abs(buf.readInt16LE(44 + (n - 1) * 2)) / 32768;
  const dur = n / sr;
  const ok = dur <= (LIMIT[name] ?? 0.5) && clip === 0 && peak < 0.98 && last < 0.002;
  if (!ok) bad++;
  console.log(
    `${name.padEnd(8)} ${dur.toFixed(2).padStart(5)}   ${db(peak).padStart(8)}   ${db(Math.sqrt(sum / n)).padStart(8)}   ${String(clip).padStart(3)}   ${last.toFixed(4)} ${ok ? "OK" : "FAIL"}`,
  );
}
if (bad) {
  console.error(`${bad} টি সাউন্ডে সমস্যা`);
  process.exit(1);
}
